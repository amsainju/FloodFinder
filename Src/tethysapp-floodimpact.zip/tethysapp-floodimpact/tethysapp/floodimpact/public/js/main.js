 var container = document.getElementById('popup');
var content = document.getElementById('popup-content');
var closer = document.getElementById('popup-closer');
var apiKey = 'Anu2X8rwVzYV5Vmqay64QZ2mSF4XeNY6fFXHwUoTSubZzzDTHp9lwfcU0Q2QMS2B';
/**
* Create an overlay to anchor the popup to the map.
*/
var overlay = new ol.Overlay(/** @type {olx.OverlayOptions} */ ({
    element: container,
    autoPan: true,
    autoPanAnimation: {
      duration: 250
    }
}));

/**
   * Add a click handler to hide the popup.
   * @return {boolean} Don't follow the href.
   */
  closer.onclick = function() {
    overlay.setPosition(undefined);
    closer.blur();
    return false;
  };


function colorHouseFunction(value){
    if(value <=20){
        return 'rgba(249, 231, 159, 0.63)';  //change to 'rgba(255, 255, 0, 0.63)'
    }
    else if(value > 20 && value <=100)
        return 'rgba(241, 196, 15, 0.63)';
    else if(value > 100 && value <=250)
        return 'rgba(214, 137, 16, 0.63)';
    else if(value > 250)
        return 'rgba(186, 74, 0, 0.63)';
    else
        return 'rgba(110, 40, 0, 0.63)';
}

//var pop10Max = 942;
//var popU18Max  = 75;
//var popO65Max = 93;
//var HousingMax = 402;
//var incomebelowProverty = 250;
//var increment =100;

var stats = document.getElementById("try").innerHTML;
stats = JSON.parse(stats);
var pop10Max = stats["pop10Max"];
var popU18Max  = stats['popU18Max'];
var popO65Max = stats['popO65Max'];
var HousingMax = stats['HousingMax'];
var incomebelowProverty = stats['incomebelowProverty'];
var increment =100;
function colorPopulationFunction(value){
   if(value <=increment){
        return 'rgba(249, 231, 159, 0.63)';  //change to 'rgba(255, 255, 0, 0.63)'
    }
    else if(value > increment && value <=2*increment)
        return 'rgba(241, 196, 15, 0.63)';
    else if(value > 2*increment && value <=3*increment)
        return 'rgba(214, 137, 16, 0.63)';
    else if(value > 3*increment&& value <=4*increment)
        return 'rgba(186, 74, 0, 0.63)';
    else
        return 'rgba(110, 40, 0, 0.63)';    
}

var currentlySelected = '';
function styleProvertyFunction(feature, resolution) {
 var value = 0;
 if(currentlySelected=="IncomeBelowProverty"){
        value = feature.get('B17017e2');
        increment = incomebelowProverty/5;  
    }
    else{
        return '';
    }
   var label = colorPopulationFunction(value);
    var style = new ol.style.Style({
        fill: new ol.style.Fill({
            //color: 'rgba(110, 40, 0, 0.63)'
            color: label
          }),
        stroke: new ol.style.Stroke({
          color: '#319FD3',
          width: 1
        }),
        text: new ol.style.Text({
          font: '12px Calibri,sans-serif',
          fill: new ol.style.Fill({
            color: '#000'
          }),
          stroke: new ol.style.Stroke({
            color: '#fff',
            width: 3
          })
        })
      }); 
    return style; 
}
function styleFunctioninundatedBlock(feature, resolution) {
    
    var value = 0;
    if(currentlySelected=="Population"){
        value = feature.get('POP10');
        increment = Math.round(pop10Max/5); 
    }
    else if(currentlySelected=="PopulationU18"){
        value = feature.get('Punder18');
        increment = Math.round(popU18Max/5); 
    }
    else if(currentlySelected=="PopulationO65"){
        value = feature.get('PopOver65');
         increment = Math.round(popO65Max/5);  
    }
    else if(currentlySelected=="Housing"){
        value = feature.get('HOUSING10');
        increment = Math.round(HousingMax/5);  
    }
   // else if(currentlySelected=="IncomeBelowProverty"){
    //    value = feature.get('B17017e2');
    //    increment = incomebelowProverty/5;  
    //}
    else{
        return '';
    }
    var label = colorPopulationFunction(value);
    var style = new ol.style.Style({
        fill: new ol.style.Fill({
            //color: "#0000ff"
            color: label
          }),
        stroke: new ol.style.Stroke({
          color: '#319FD3',
          width: 1
        }),
        text: new ol.style.Text({
          font: '12px Calibri,sans-serif',
          fill: new ol.style.Fill({
            color: '#000'
          }),
          stroke: new ol.style.Stroke({
            color: '#fff',
            width: 3
          })
        })
      }); 
    return style; 
}
function populationDataChecked(value) {
    currentlySelected = value;
    inundatedBlocksLayer.setStyle(styleFunctioninundatedBlock);
    //inundatedBlocksLayer.setStyle(styleFunctioninundatedBlock);
    if(value==''){                                  //hinding the legend
       document.getElementById('Population').innerHTML = '';
        document.getElementById('Population').style.border ="none";
    }
    else if(value!=''){
        var legendHead = '';
        if(value=="Population"){
            legendHead = '<p>Total Population: </p>';
        }
        else if(value=="PopulationU18"){
            legendHead = '<p>Under 18 years old: </p>';
        }
        else if(value=="PopulationO65"){
            legendHead = '<p>65 years old and over: </p>';
        }
        else if(value=="Housing"){
            legendHead = '<p>Housing: </p>';
        }
        else if(value=="IncomeBelowProverty"){
            legendHead = '<p>Income below proverty: </p>';
        }
        var targetBox = $("." + 'Population');
        document.getElementById('Population').style.border ="2px solid gray";
        document.getElementById('Population').innerHTML = legendHead +
       '<div class="foo oneFifth"></div><p class="space"> 0 to ' +increment+'</p>'+
       '<div class="foo twoFifth"></div><p class="space">'+(increment+1)+' to '+(2*increment)+'</p>'+
       '<div class="foo thirdFifth"></div><p class="space">'+(2*increment+1)+' to '+(3*increment)+'</p>'+
       '<div class="foo fourthFifth"></div><p class="space">'+(3*increment+1)+' to '+(4*increment)+'</p>'+
       '<div class="foo fifthFifth"></div><p class="space">'+(4*increment+1)+' to '+(5*increment)+'</p>';
        $(".box").not(targetBox).hide();
        $(targetBox).show();
    }
    else{
        info.innerHTML = '';
    }
}

function countiesBoundaryStyle(feature) {
    var name = feature.get('NAME');
 var cbstyle =
     new ol.style.Style({
        fill: '',
        stroke: new ol.style.Stroke({
          color: '#B7B700',
          width: 2
        }),
        text: new ol.style.Text({
          font: '16px Calibri,sans-serif',
          fill: new ol.style.Fill({
            color: '#E1320B'
          }),
          stroke: new ol.style.Stroke({
            color: '#fff',
            width: 3
          }),
          text: name
        })
      });
    return cbstyle;
}



var inundatedBlocksLayer = new ol.layer.Vector({
        source: new ol.source.Vector({
          url: 'https://raw.githubusercontent.com/amsainju/FloodImpact/master/Data/inundatedPopulationBlock.geojson',
          //url: 'https://openlayers.org/en/v4.2.0/examples/data/geojson/countries.geojson',
          format: new ol.format.GeoJSON()
        }),
        style: styleFunctioninundatedBlock
      });

//var inundatedProvertyLayer = new ol.layer.Vector({
//       source: new ol.source.Vector({
//          url: 'https://raw.githubusercontent.com/amsainju/FloodImpact/master/Data/inundatedProvertyLevel.geojson',
//          //url: 'https://openlayers.org/en/v4.2.0/examples/data/geojson/countries.geojson',
//          format: new ol.format.GeoJSON()
//        }),
//        style: styleProvertyFunction
//      });

var countiesBoundaryLayer = new ol.layer.Vector({
        source: new ol.source.Vector({
          url: 'https://raw.githubusercontent.com/amsainju/FloodImpact/master/Data/TX_county_boundaries_WGS.geojson',
          //url: 'https://openlayers.org/en/v4.2.0/examples/data/geojson/countries.geojson',
          format: new ol.format.GeoJSON()
        }),
         style: countiesBoundaryStyle

      });

var styles = [
        'Road',
        'Aerial',
        'AerialWithLabels',
        'collinsBart'
      ];

var layers = [];

var i, ii;
      for (i = 0, ii = styles.length; i < ii; ++i) {
        layers.push(new ol.layer.Tile({
          visible: false,
          preload: Infinity,
          source: new ol.source.BingMaps({
            key: apiKey,
            imagerySet: styles[i]
            // use maxZoom 19 to see stretched tiles instead of the BingMaps
            // "no photos at this zoom level" tiles
            // maxZoom: 19
          })
        }));
          
      }

var view= new ol.View({
    center: ol.proj.transform([-98.41,30.06], 'EPSG:4326', 'EPSG:3857'),
    minZoom:10,
    zoom: 10
    });

var map = new ol.Map({
    layers: layers,
    overlays: [overlay],
    loadTilesWhileInteracting: true,
    target: 'map',
    controls: ol.control.defaults().extend([
      new ol.control.ScaleLine()
    ]),
    view: view
});


var select = document.getElementById('layer_select');
  function onChange() {
    var style = select.value;
    for (var i = 0, ii = layers.length; i < ii; ++i) {
      layers[i].setVisible(styles[i] === style);
    }
  }
select.addEventListener('change', onChange);
onChange();

//var url = "https://raw.githubusercontent.com/amsainju/FloodImpact/master/Data/zip_codes_states.json";
//var zipcodes = require(url);
function getLocation(){
    var zipcode = document.getElementById("myZip").value;
    if (zipcode =="Enter Zip..." || zipcode ==""){
        return;
    }
     if (!navigator.geolocation){
         //do alert
         return;
     }
     function success(position) {
      var latitude  = position.coords.latitude;
      var longitude = position.coords.longitude;
      map.getView().setCenter(ol.proj.transform([longitude, latitude], 'EPSG:4326', 'EPSG:3857'));
      map.getView().setZoom(15);
    }
    
     function error() {
       var latitude  = 33.2176103;
       var longitude = -87.53463049999999;
       map.getView().setCenter(ol.proj.transform([longitude, latitude], 'EPSG:4326', 'EPSG:3857'));
       map.getView().setZoom(15);
  }
    
   navigator.geolocation.getCurrentPosition(success, error);            
}

map.addLayer(countiesBoundaryLayer);
map.addLayer(inundatedBlocksLayer);
inundatedBlocksLayer.set('selectable',true);
//map.addLayer(inundatedProvertyLayer);
//inundatedProvertyLayer.set('selectable',false);
//mouse pointer to coordinate control
var mousePositionControl = new ol.control.MousePosition({
  coordinateFormat: ol.coordinate.createStringXY(2),
  projection: 'EPSG:4326'
});
map.addControl(mousePositionControl);

// Create an image layer
var imageLayer = new ol.layer.Image({
    opacity: 0.75,
    source: new ol.source.ImageStatic({
        url: 'https://raw.githubusercontent.com/amsainju/FloodImpact/master/Data/flood_depth_5blu.png',
        imageSize: [5440, 1940],
        projection: map.getView().getProjection(),
        imageExtent: ol.extent.applyTransform([-98.71447264032248, 29.90934173194351,  -97.86321117065424, 30.169749962751283
], ol.proj.getTransform("EPSG:4326", "EPSG:3857"))

        //imageExtent: ol.extent.applyTransform([-74.22655, 40.71222, -74.12544, 40.77394], ol.proj.getTransform("EPSG:4326", "EPSG:3857"))
    })
});

map.addLayer(imageLayer);


var polygonStyle = new ol.style.Style({
          stroke: new ol.style.Stroke({
            color: '#ff0000',
            width: 2
        })
      });

    var pointStyle = new ol.style.Style({
             image: new ol.style.Circle({
               radius: 5,
               fill: new ol.style.Fill({
                 color: '#25bef0'
               }),
               stroke: new ol.style.Stroke({
                 color: '#ffffff'
               })
             })
           });

var select_interaction = new ol.interaction.Select({
    layers: function(layer) {
          return layer.get('selectable') == true;
        },
    style: [pointStyle,polygonStyle]
});
map.addInteraction(select_interaction);

map.on('singleclick', function(evt) {
    select_interaction.getFeatures().on('change:length', function(e){
        if (e.target.getArray().length > 0)
        {
         // this means there is at least 1 feature selected
            var selected_feature = e.target.item(0); // 1st feature in Collection
        
            var coordinate = evt.coordinate;
            if(selected_feature.get('POP10')){
                
                var popup_content = '<p>Total Population: '+ selected_feature.get('POP10')+'</p>'+
                    '<p>Under 18 years old: '+ selected_feature.get('Punder18')+'</p>' +
                    '<p>65 years old and over: '+ selected_feature.get('PopOver65')+'</p>' +
                    '<p>Housing Units: '+ selected_feature.get('HOUSING10')+'</p>';
                //$(content).popover('destroy');
                // Delay arbitrarily to wait for previous popover to
                // be deleted before showing new popover.
                setTimeout(function() {
                    overlay.setPosition(coordinate);
                    content.innerHTML = popup_content;
                }, 500);
            }
            else if(selected_feature.get('FType')){
                var popup_content = '<p>Name: '+ selected_feature.get('Name')+'</p>'+
                    '<p>Address: '+ selected_feature.get('Address')+'</p>'
                +
                    '<p>City: '+ selected_feature.get('City')+'</p>'
                +
                    '<p>State: '+ selected_feature.get('State')+'</p>'
                +
                    '<p>Zip Code: '+ selected_feature.get('Zipcode')+'</p>';
                //$(content).popover('destroy');
                // Delay arbitrarily to wait for previous popover to
                // be deleted before showing new popover.
                setTimeout(function() {
                    overlay.setPosition(coordinate);
                    content.innerHTML = popup_content;
                }, 500);
            }
            else if(selected_feature.get('FacilityTy')){
                var popup_content = '<p>Name: '+ selected_feature.get('FullName')+'</p>'+
                    '<p>Facility Type: '+ selected_feature.get('FacilityTy')+'</p>';
                //$(content).popover('destroy');
                // Delay arbitrarily to wait for previous popover to
                // be deleted before showing new popover.
                setTimeout(function() {
                    overlay.setPosition(coordinate);
                    content.innerHTML = popup_content;
                }, 500);
            }
        }
        //else {
            // remove pop up when selecting nothing on the map
           // $(content).popover('destroy');
       // }
                      
    });
    
 });

//document.getElementById('OpenLayers_Control_Attribution_7').style.border ="2px solid gray";
//document.getElementById('OpenLayers_Control_Attribution_7').innerHTML = '<p>Water Depth(ft):</p>'+
 //   '<div class="foo firstDepth"></div><p class="space"> 0.5 to 1</p>'+
 //   '<div class="foo secondDepth"></div><p class="space">1 to 3</p>'+
  //  '<div class="foo thirdDepth"></div><p class="space"> 3 to 6</p>'+
   // '<div class="foo forthDepth"></div><p class="space">6 to 15</p>'+
    //'<div class="foo fifthDepth"></div><p class="space"> > 15</p>';



