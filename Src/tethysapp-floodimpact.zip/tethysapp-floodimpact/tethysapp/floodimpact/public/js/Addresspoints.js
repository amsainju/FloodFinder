var policeandFireLocation = new ol.layer.Vector({
        source: new ol.source.Vector({
          url: 'https://raw.githubusercontent.com/amsainju/FloodImpact/master/Data/policeandfire.geojson', //change url
          //url: 'https://openlayers.org/en/v4.2.0/examples/data/geojson/countries.geojson',
          format: new ol.format.GeoJSON()
        }),
        style: new ol.style.Style({
            image: new ol.style.Circle({
              radius: 8,
              stroke: new ol.style.Stroke({
                color: 'white',
                width: 2
              }),
              fill: new ol.style.Fill({
                color: 'red'
              })
            })
          })
      });

var airportsLocation = new ol.layer.Vector({
        source: new ol.source.Vector({
          url: 'https://raw.githubusercontent.com/amsainju/FloodImpact/master/Data/AirportLocations.geojson', //change url
          //url: 'https://openlayers.org/en/v4.2.0/examples/data/geojson/countries.geojson',
          format: new ol.format.GeoJSON()
        }),
        style: new ol.style.Style({
          image: new ol.style.RegularShape({
            fill: new ol.style.Fill({color: '#926239'}),
            stroke: new ol.style.Stroke({color: 'white', width: 2}),
            points: 4,
            radius: 8,
            angle: Math.PI / 4
          })
        })
      });
airportsLocation.set('selectable',true);
function styleRoadFunction(feature){
    var value = feature.get('RTE_CLASS_');
    var color ='#00FA9A';
    var width = 0;
    if(value =='County Roads'){
       // color = '##00FA9A';
        width =4 ;
    }
    else if(value =='FC Streets'){
     //   color = '##00FA9A';
        width =1 ;
    }
    else if(value =='Federal Roads'){
     //   color = '#00FF00';
        width =5 ;
    }
    else if(value =='Local Street'){
     //   color = '#00FF00';
        width =1 ;
    }
    else if(value =='On System Highways'){
      //  color = '#00FF00';
        width =8 ;
    }    
    var rStyle = new ol.style.Style({
        stroke: new ol.style.Stroke({
          color: color,
          width: width
            })
        })
    return rStyle;
}
   var bridgeLayer = new ol.layer.Vector({
        opacity: 0.75,
        source: new ol.source.Vector({
          url: 'https://raw.githubusercontent.com/amsainju/FloodImpact/master/Data/BridgeData.geojson', //change url
          //url: 'https://openlayers.org/en/v4.2.0/examples/data/geojson/countries.geojson',
          format: new ol.format.GeoJSON()
        }),
        style: new ol.style.Style({
          image: new ol.style.RegularShape({
            fill: new ol.style.Fill({color: '#551a8b'}),
            stroke: new ol.style.Stroke({color: 'white', width: 2}),
            points: 4,
            radius: 8,
            angle: Math.PI / 4
          })
        })
      });

policeandFireLocation.set('selectable',true);
 function policeandFireFunction(){
     var policeChecked = document.getElementById("police").checked;
     if(policeChecked){
         document.getElementById("displayPolice").style.display = 'block';
         map.addLayer(policeandFireLocation);
     }
     else{
         document.getElementById("displayPolice").style.display = 'none';
          map.removeLayer(policeandFireLocation);
     }
  }

var medicalLocation = new ol.layer.Vector({
        source: new ol.source.Vector({
          url: 'https://raw.githubusercontent.com/amsainju/FloodImpact/master/Data/hospitals.geojson', //change url
          //url: 'https://openlayers.org/en/v4.2.0/examples/data/geojson/countries.geojson',
          format: new ol.format.GeoJSON()
        }),
        style: new ol.style.Style({
            image: new ol.style.Circle({
              radius: 8,
              stroke: new ol.style.Stroke({
                color: 'white',
                width: 2
              }),
              fill: new ol.style.Fill({
                color: '#0000b2'
              })
            })
          })
      });

medicalLocation.set('selectable',true);
 function medicalFunction(){
     var medicalChecked = document.getElementById("medical").checked;
     if(medicalChecked){
         document.getElementById("displayMedical").style.display = 'block';
         map.addLayer(medicalLocation);
     }
     else{
         document.getElementById("displayMedical").style.display = "none";
          map.removeLayer(medicalLocation);
     }
  }

var schoolsLocation = new ol.layer.Vector({
        source: new ol.source.Vector({
          url: 'https://raw.githubusercontent.com/amsainju/FloodImpact/master/Data/schools.geojson', //change url
          //url: 'https://openlayers.org/en/v4.2.0/examples/data/geojson/countries.geojson',
          format: new ol.format.GeoJSON()
        }),
        style: new ol.style.Style({
            image: new ol.style.Circle({
              radius: 8,
              stroke: new ol.style.Stroke({
                color: 'white',
                width: 2
              }),
              fill: new ol.style.Fill({
                color: '#b2b200'
              })
            })
          })
      });

schoolsLocation.set('selectable',true);
 function schoolsFunction(){
     var schoolsChecked = document.getElementById("schools").checked;
     
     if(schoolsChecked){
         document.getElementById("displaySchool").style.display = 'block';
         map.addLayer(schoolsLocation);
     }
     else{
         document.getElementById("displaySchool").style.display = "none";
          map.removeLayer(schoolsLocation);
     }
  }

 function bridgeFunction(){
     var bridgeChecked = document.getElementById("bridge").checked;
     
     if(bridgeChecked){
         document.getElementById("displayBridges").style.display = 'block';
         map.addLayer(bridgeLayer);
     }
     else{
         document.getElementById("displayBridges").style.display = "none";
          map.removeLayer(bridgeLayer);
     }
  }

 function airportFunction(){
     var airportChecked = document.getElementById("airports").checked;
     
     if(airportChecked){
         document.getElementById("displayAirports").style.display = 'block';
         map.addLayer(airportsLocation);
     }
     else{
         document.getElementById("displayAirports").style.display = "none";
          map.removeLayer(airportsLocation);
     }
  }

//for cluster data

var earthquakeFill = new ol.style.Fill({
        color: 'rgba(236, 121, 5, 0.8)'
      });
      var earthquakeStroke = new ol.style.Stroke({
        color: 'rgba(255, 204, 0, 0.2)',
        width: 3
      });
      var textFill = new ol.style.Fill({
        color: '#fff'
      });
      var textStroke = new ol.style.Stroke({
        color: 'rgba(0, 0, 0, 0.6)',
        width: 3
      });
      var invisibleFill = new ol.style.Fill({
        color: 'rgba(255, 255, 255, 0.01)'
      });

      function createEarthquakeStyle(feature) {
        // 2012_Earthquakes_Mag5.kml stores the magnitude of each earthquake in a
        // standards-violating <magnitude> tag in each Placemark.  We extract it
        // from the Placemark's name instead.
        //var name = feature.get('name');
        var magnitude = parseFloat(name.substr(2));
          radius = 5;
        //var radius = 5 + 20 * (magnitude - 5);

        return new ol.style.Style({
          geometry: feature.getGeometry(),
          image: new ol.style.RegularShape({
            radius1: radius,
            radius2: 8,
            points: 100,
            angle: Math.PI,
            fill: earthquakeFill,
            stroke: earthquakeStroke
          })
        });
      }

      var maxFeatureCount, vector;
      function calculateClusterInfo(resolution) {
        maxFeatureCount = 0;
        var features = vector.getSource().getFeatures();
        var feature, radius;
        for (var i = features.length - 1; i >= 0; --i) {
          feature = features[i];
          var originalFeatures = feature.get('features');
          var extent = ol.extent.createEmpty();
          var j, jj;
          for (j = 0, jj = originalFeatures.length; j < jj; ++j) {
            ol.extent.extend(extent, originalFeatures[j].getGeometry().getExtent());
          }
          maxFeatureCount = Math.max(maxFeatureCount, jj);
          radius = 0.25 * (ol.extent.getWidth(extent) + ol.extent.getHeight(extent)) /
              resolution;
          feature.set('radius', radius);
        }
      }

      var currentResolution;
      function styleFunction(feature, resolution) {
        if (resolution != currentResolution) {
          calculateClusterInfo(resolution);
          currentResolution = resolution;
        }
        var style;
        var size = feature.get('features').length;
        if (size > 1) {
          style = new ol.style.Style({
            image: new ol.style.Circle({
              radius: feature.get('radius'),
              fill: new ol.style.Fill({
                color: [236, 121, 5, Math.min(0.8, 0.4 + (size / maxFeatureCount))]
              })
            }),
            text: new ol.style.Text({
              text: size.toString(),
              fill: textFill,
              stroke: textStroke
            })
          });
        } else {
          var originalFeature = feature.get('features')[0];
          style = createEarthquakeStyle(originalFeature);
        }
        return style;
      }

      function selectStyleFunction(feature) {
        var styles = [new ol.style.Style({
          image: new ol.style.Circle({
            radius: feature.get('radius'),
            fill: invisibleFill
          })
        })];
        var originalFeatures = feature.get('features');
        var originalFeature;
        for (var i = originalFeatures.length - 1; i >= 0; --i) {
          originalFeature = originalFeatures[i];
          styles.push(createEarthquakeStyle(originalFeature));
        }
        return styles;
      }

      vector = new ol.layer.Vector({
        source: new ol.source.Cluster({
          distance: 40,
          source: new ol.source.Vector({
              url: 'https://raw.githubusercontent.com/amsainju/FloodImpact/master/Data/inundatedAddressPoints.geojson',
              //url: 'https://openlayers.org/en/v4.2.0/examples/data/geojson/countries.geojson',
              format: new ol.format.GeoJSON()
            })
        }),
        style: styleFunction
      });
//map.addLayer(vector);

 function addresspointsDisplay(){
     var addresspointsChecked = document.getElementById("addressPoints").checked;
     if(addresspointsChecked){
         document.getElementById("displayAddress").style.display = 'block';
         map.addLayer(vector);
     }
     else{
          document.getElementById("displayAddress").style.display = 'none';
          map.removeLayer(vector);
     }
     
 }

vector.set('selectable',false);