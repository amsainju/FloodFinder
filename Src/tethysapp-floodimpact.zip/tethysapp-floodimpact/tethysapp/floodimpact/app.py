from tethys_sdk.base import TethysAppBase, url_map_maker


class Floodimpact(TethysAppBase):
    """
    Tethys app class for FloodImpact.
    """

    name = 'FloodImpact'
    index = 'floodimpact:home'
    icon = 'floodimpact/images/icon.PNG'
    package = 'floodimpact'
    root_url = 'floodimpact'
    color = '#3366cc'
    description = ' web application to identify flood extent and '
    tags = 'Flood, SI2017'
    enable_feedback = False
    feedback_emails = []

    def url_maps(self):
        """
        Add controllers
        """
        UrlMap = url_map_maker(self.root_url)

        url_maps = (
            UrlMap(
                name='home',
                url='floodimpact',
                controller='floodimpact.controllers.home'
            ),
        )

        return url_maps
