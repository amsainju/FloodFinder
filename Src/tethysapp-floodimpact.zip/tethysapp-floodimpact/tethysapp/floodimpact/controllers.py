from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from tethys_sdk.gizmos import Button
from tethys_sdk.gizmos import SelectInput
import requests
import json
from tethys_sdk.gizmos import DataTableView

maxDict= {}
dog_dict = {}
dog_dict['breed'] = 1
dog_dict['size'] = 10
js = json.dumps(dog_dict)

@login_required()
def home(request):
    """
    Controller for the app home page.
    """
    #send_url = 'http://freegeoip.net/json'
    #r = requests.get(send_url)
    #j = json.loads(r.text)
    #latitude = j['latitude']
   #longitude = j['longitude']
    r = requests.get('https://raw.githubusercontent.com/amsainju/FloodImpact/master/Data/inundatedPopulationBlock.geojson')
    data = json.loads(r.text)

    populationAffected = 0
    housingAffected = 0
    schoolAffected = 0
    popOver65Affected  = 0
    popUnder18Affected = 0
    policeandFireStationAffected = 0
    medicalCenterAffected = 0
    AdressPointAffected = 0
    airportAffected = 0
    bridgesAffected = 6
    pop10Max = 0
    popU18Max  = 0
    popO65Max = 0
    HousingMax = 0
    
    
    for prop in data['features']:
        if(prop['properties']['POP10']>pop10Max):
            pop10Max = prop['properties']['POP10']
        
        if(prop['properties']['HOUSING10']>HousingMax):
            HousingMax = prop['properties']['HOUSING10']
        
        if(prop['properties']['Punder18']>popU18Max):
            popU18Max = prop['properties']['Punder18']
        
        if(prop['properties']['PopOver65']>popO65Max):
            popO65Max = prop['properties']['PopOver65']
        
        housingAffected = housingAffected +prop['properties']['HOUSING10']
        populationAffected = populationAffected +prop['properties']['POP10']    
        popUnder18Affected = popUnder18Affected +prop['properties']['Punder18'] 
        popOver65Affected = popOver65Affected +prop['properties']['PopOver65']
    maxDict['pop10Max']=pop10Max
    maxDict['popU18Max']=popU18Max
    maxDict['popO65Max']=popO65Max
    maxDict['HousingMax']=HousingMax
    maxDict['incomebelowProverty'] = 214  #modify later
    jsonStats = json.dumps(maxDict)
    r = requests.get('https://raw.githubusercontent.com/amsainju/FloodImpact/master/Data/inundatedAddressPoints.geojson')
    data = json.loads(r.text)
    AdressPointAffected = len(data['features']);

    table_rows = []
    #r = requests.get('https://raw.githubusercontent.com/amsainju/FloodImpact/master/Data/inundatedPoliceandfire.geojson')
    #data = json.loads(r.text)
    #policeandFireStationAffected = len(data['features']);
    #for prop in data['features']:
     #   if(prop['properties']['FType']==740):
      #      policeandFireStationAffected +=1 
        #elif(prop['properties']['FType']==730):
        #    schoolAffected +=1
        #elif(prop['properties']['FType']==820):
        #    parkAffected +=1
        #elif(prop['properties']['FType']==800):
        #    medicalCenterAffected+=1
    table_rows.append(
        (
            'Housing Units',housingAffected,  'Bridges' , bridgesAffected, 
        )
    )
    table_rows.append(
        (
            'Address Points', AdressPointAffected, 'Airports' , airportAffected,
        )
    )
    table_rows.append(
        (
            'Population 65 years and over', int(popOver65Affected),'Schools',schoolAffected,
        )
    )
    table_rows.append(
        (
            'Population under 18 years old', int(popUnder18Affected),'Police and Fire Stations',policeandFireStationAffected,
        )
    )
    table_rows.append(
        (
            'Total Population', populationAffected, 'Hospitals and Medical Centers',medicalCenterAffected, 
        )
    )  
    summary_table = DataTableView(
        column_names=('Data', 'Total Count','Data','Total Count'),
        rows=table_rows,
        searching=False,
        orderClasses=False,
        paging= False,
        footer = False,
        #lengthMenu=[ [10, 25, 50, -1], [10, 25, 50, "All"] ],
    )


    # Realtime innundation map forcast button
    btn_getInnundationMap = Button(display_text='View Flood Forecast',
                           name='btnForecast',
                           attributes='form=forecast-form',
                           disabled = False,
                           submit=True)
    
    si_precipitationValue = SelectInput(display_text='Choose Precipitation Value',
                           name='select1',
                           multiple=False,
                           original=True,
                           disabled= True,
                           options=[('One', '1'), ('Two', '2'), ('Three', '3')],
                           initial=['Three'])
    
    layer_select = SelectInput(display_text='Change Basemap',
                           name='layer_select',
                           multiple=False,
                           original=True,
                           options=[('Aerial', 'Aerial'), ('AerialWithLabels', 'AerialWithLabels'), ('Road', 'Road'), ('collinsBart', 'collinsBart')],
                           initial=['collinsBart'])
    
    toggle_overlayLayers = SelectInput(display_text='Select the WMS layer you wish to view:',
                           name='js-layers',
                           multiple=False,
                           original=True,
                           options=[('Choose',''),('Population', 'populationLayer'), ('Manhatten', 'manhattenLayer'),('Texas State', 'texasStateLayer')],
                           initial=['Choose'])
    
    btn_locateMe = Button(display_text='LocateMe',
                           name='locateMe',
                           attributes='form=locateme-form',
                           submit=True)
     
    save_button = Button(
        display_text='',
        name='save-button',
        icon='glyphicon glyphicon-floppy-disk',
        style='success',
        attributes={
            'data-toggle':'tooltip',
            'data-placement':'top',
            'title':'Save'
        }
    )

    edit_button = Button(
        display_text='',
        name='edit-button',
        icon='glyphicon glyphicon-edit',
        style='warning',
        attributes={
            'data-toggle':'tooltip',
            'data-placement':'top',
            'title':'Edit'
        }
    )

    remove_button = Button(
        display_text='',
        name='remove-button',
        icon='glyphicon glyphicon-remove',
        style='danger',
        attributes={
            'data-toggle':'tooltip',
            'data-placement':'top',
            'title':'Remove'
        }
    )

    previous_button = Button(
        display_text='Previous',
        name='previous-button',
        attributes={
            'data-toggle':'tooltip',
            'data-placement':'top',
            'title':'Previous'
        }
    )

    next_button = Button(
        display_text='Next',
        name='next-button',
        attributes={
            'data-toggle':'tooltip',
            'data-placement':'top',
            'title':'Next'
        }
    )

    context = {
        'jsonStats':jsonStats,
        'summary_table': summary_table,
        #'latitude' :latitude,
        #'longitude' :longitude,
        'btn_locateMe':btn_locateMe,
        'toggle_overlayLayers':toggle_overlayLayers,
        'layer_select': layer_select,
        'btn_getInnundationMap': btn_getInnundationMap,
        'si_precipitationValue': si_precipitationValue,
        'save_button': save_button,
        'edit_button': edit_button,
        'remove_button': remove_button,
        'previous_button': previous_button,
        'next_button': next_button
    }

    return render(request, 'floodimpact/home.html', context)